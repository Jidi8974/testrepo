import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

//Maximiliano Garrido, Trent McPeters, Yuhei Masuda
//CS435 assignment 6.2 (Problem 1)
//Oct 7
//When testing, please change path name on line 23 to read an external file
public class SpreadsheetShuffle {
	public static void main(String[] args) {
		ArrayList<List<String>> list1 = readFile();
		arrangeOrder(list1);
	}
	public static ArrayList<List<String>> readFile(){//read an external file
		ArrayList<List<String>> list1 = new ArrayList<List<String>>();
		try (var reader = new BufferedReader(
				new FileReader(
						new File("/Users/yuhei/Downloads/input.txt")))) {// Change path to read
			// 2.read each line
			String line = null;
			while((line = reader.readLine()) != null) {
				String[] strs = line.split("," , -1);
				List<String> list2 = Arrays.asList(strs);;
				list1.add(list2);
			}
		} catch (FileNotFoundException e) {
			// file not exists
			e.printStackTrace();
		} catch (IOException e) {
			// failed to read file
			e.printStackTrace();
		}
		return list1;
	}
	public static void arrangeOrder(ArrayList<List<String>> list1) {
		int[] order = new int[list1.get(1).size()];
		for(int i = 0;i < order.length; i++) {
			order[i] = Integer.parseInt(list1.get(1).get(i));
		}
		list1.remove(1);//delete second line
		list1.remove(1);//delete third line

		for(List<String> l : list1) {
			String[] strs = new String[l.size()];
			for(int i = 0; i < strs.length; i++) {
				if(order[i] == 0) {

				}else {
					strs[order[i]-1] = l.get(i);
				}
			}
			strs = Arrays.stream(strs).filter(s -> (s != null && s.length() > 0)).toArray(String[]::new);
			String str = String.join(",", strs);
			System.out.println(str);
		}

	}
}
